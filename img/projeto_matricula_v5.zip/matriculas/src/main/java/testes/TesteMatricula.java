/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

import model.bean.*;

/**
 *
 * @author Aluno
 */
public class TesteMatricula {
    public static void main(String[] args) {
        // Definir um objeto do Professor
        Professor prof = new Professor();
        prof.setId(1);
        prof.setNome("João da Silva");
        prof.setEmail("joao@gmail.com");
        prof.setTelefone("(41)9 9988-7755");
        
        // Definir dois objetos de estudantes
        Estudante e1 = new Estudante();
        e1.setId(2);
        e1.setNome("Maria Conceição");
        e1.setCpf("000.111.222-33");
        
        Estudante e2 = new Estudante();
        e2.setId(3);
        e2.setNome("Caubi Peixoto");
        e2.setCpf("123.456.789-00");
        
        // Definir o objeto do curso
        Curso esteCurso = new Curso();
        esteCurso.setId(1);
        esteCurso.setNome("Programação básica de Python");
        esteCurso.setCargaHoraria(40);
        esteCurso.setProfessor(prof); // Assoc. com o professor
        esteCurso.getEstudantes().add(e1);
        esteCurso.getEstudantes().add(e2);
        
        // Mostrar um resumo do curso
        System.out.println("Curso: " + esteCurso.getNome());
        System.out.println("CH: " + esteCurso.getCargaHoraria());
        System.out.println("Professor: " + esteCurso.getProfessor());
        System.out.println("Estudantes:");
        for(Estudante e : esteCurso.getEstudantes()) {
            System.out.println(" - " + e);
        }
    }
}
