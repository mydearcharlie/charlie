/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.bean.Professor;

/**
 *
 * @author Aluno
 */
public class ProfessorDAO {
    public void create(Professor p) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            // Cadastrar inicialmente o usuário
            String sql = "INSERT INTO usuario(nome,email,senha) VALUES(?,?,?)";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());
            stmt.setString(3, p.getSenha());
            
            stmt.executeUpdate();
            
            // Cadastrar o professor
            sql = "INSERT INTO professor(id_usuario,telefone) VALUES ((SELECT MAX(id_usuario) from usuario),?)";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, p.getTelefone());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Professor cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao cadastrar professor. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    public ArrayList<Professor> read() {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<Professor> professores = new ArrayList();
        
        try {
            String sql = "SELECT * FROM professor p INNER JOIN usuario u ON p.id_usuario = u.id_usuario";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while(rs.next()) {
                Professor p = new Professor();
                p.setId(rs.getInt("id_usuario"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                p.setTelefone(rs.getString("telefone"));
                
                professores.add(p);
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar professores. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt, rs);
        }
        
        return professores;
    }
    
    public void update(Professor p) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            // Atualizar dados do usuário
            String sql = "UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE id_usuario = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());
            stmt.setString(3, p.getSenha());
            stmt.setInt(4, p.getId());
            
            stmt.executeUpdate();
            
            // Atualizar dados do professor
            sql = "UPDATE professor SET telefone = ? WHERE id_usuario = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, p.getTelefone());
            stmt.setInt(2, p.getId());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Professor atualizado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao atualizar professor. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    public void destroy(Professor p) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            // Excluir primeiramente o professor (por conta da chave estrangeira)
            String sql = "DELETE FROM professor WHERE id_usuario = ?";
            stmt = con.prepareStatement(sql);            
            stmt.setInt(1, p.getId());
            
            stmt.executeUpdate();
            
            // Excluir o usuário
            sql = "DELETE FROM usuario WHERE id_usuario = ?";
            stmt = con.prepareStatement(sql);            
            stmt.setInt(1, p.getId());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Professor excluído com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao excluir professor. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
}
