/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.bean.Curso;
import model.bean.Estudante;
import model.bean.Professor;

/**
 *
 * @author grego
 */
public class CursoDAO {
    public void create(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            String sql = "INSERT INTO curso(nome,carga_horaria,data_inicio,data_fim,id_professor) "
                    + "VALUES(?,?,?,?,?)";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setInt(2, c.getCargaHoraria());
            stmt.setDate(3, c.getDataInicio());
            stmt.setDate(4, c.getDataFim());
            // Chave estrangeira
            stmt.setInt(5, c.getProfessor().getId());
            
            stmt.executeUpdate();
            
            // Invoca o método para adicionar estudantes ao curso
            addEstudantes(c.getEstudantes());
            
            JOptionPane.showMessageDialog(null, "Curso cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao cadastrar curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    public ArrayList<Curso> read() {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<Curso> cursos = new ArrayList();
        
        try {
            String sql = "SELECT * "
                    + "FROM curso c INNER JOIN professor p ON c.id_professor = p.id_usuario "
                    + "INNER JOIN usuario u on p.id_usuario = u.id_usuario";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while(rs.next()) {
                Curso c = new Curso();
                c.setId(rs.getInt("id_curso"));
                c.setNome(rs.getString("c.nome"));
                c.setCargaHoraria(rs.getInt("carga_horaria"));
                c.setDataInicio(rs.getDate("data_inicio"));
                c.setDataFim(rs.getDate("data_fim"));
                // Instanciar um objeto de professor a partir do resultado da query
                Professor p = new Professor();
                p.setId(rs.getInt("id_professor"));
                p.setNome(rs.getString("u.nome"));
                
                // Definir o valor do atributo de professor associado ao curso
                c.setProfessor(p);
                
                cursos.add(c);
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar cursos. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt, rs);
        }
        
        return cursos;
    }
    
    public void update(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            String sql = "UPDATE curso "
                    + "SET nome = ?, carga_horaria = ?, data_inicio = ?, data_fim = ?, id_professor = ? "
                    + "WHERE id_curso = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, c.getNome());
            stmt.setInt(2, c.getCargaHoraria());
            stmt.setDate(3, c.getDataInicio());
            stmt.setDate(4, c.getDataFim());
            stmt.setInt(5, c.getProfessor().getId());
            stmt.setInt(6, c.getId());
            
            stmt.executeUpdate();
            
            // Invoca os métodos para atualizar as matrículas
            removeEstudantes(c); // Removo todos os estudantes do curso
            addEstudantes(c); // Adiciona uma nova lista de estudantes
            
            JOptionPane.showMessageDialog(null, "Curso editado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao editar curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    public void destroy(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            String sql = "DELETE FROM curso WHERE id_curso = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, c.getId());
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao excluir curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    // Adiciona uma lista de estudantes no último curso cadastrado (create)
    public void addEstudantes(ArrayList<Estudante> estudantes) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            // Estudantes
            for(Estudante e : estudantes) {
                String sql = "INSERT INTO matricula(id_curso,id_estudante) VALUES ((SELECT MAX(id_curso) FROM curso),?)";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, e.getId());
                
                stmt.executeUpdate();
            }
            
            //JOptionPane.showMessageDialog(null, "Curso cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao matricular estudante no curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    // Sobrecarga do método addEstudates para adicionar uma lista de estudantes em determinado curso (update)
    public void addEstudantes(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            // Estudantes
            for(Estudante e : c.getEstudantes()) {
                String sql = "INSERT INTO matricula(id_curso,id_estudante) VALUES (?,?)";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, c.getId());
                stmt.setInt(2, e.getId());
                
                stmt.executeUpdate();
            }
            
            //JOptionPane.showMessageDialog(null, "Curso cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao matricular estudante no curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
    
    // Removo todos os estudantes de um curso específico
    public void removeEstudantes(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        
        try {
            String sql = "DELETE FROM matricula WHERE id_curso = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, c.getId());

            stmt.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Curso cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Falha ao remover estudante no curso. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt);
        }
    }
}
