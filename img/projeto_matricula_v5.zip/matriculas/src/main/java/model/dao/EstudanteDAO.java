/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.bean.Curso;
import model.bean.Estudante;

/**
 *
 * @author grego
 */
public class EstudanteDAO {
    public ArrayList<Estudante> read() {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<Estudante> estudantes = new ArrayList();
        
        try {
            String sql = "SELECT * FROM estudante e INNER JOIN usuario u ON e.id_usuario = u.id_usuario";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while(rs.next()) {
                Estudante e = new Estudante();
                e.setId(rs.getInt("id_usuario"));
                e.setNome(rs.getString("nome"));
                e.setEmail(rs.getString("email"));
                e.setCpf(rs.getString("cpf"));
                
                estudantes.add(e);
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar estudantes. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt, rs);
        }
        
        return estudantes;
    }
    
    // Sobrecarga do método "read" para retornar apenas os estudantes de determinado curso
    public ArrayList<Estudante> read(Curso c) {
        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList<Estudante> estudantes = new ArrayList();
        
        try {
            String sql = "SELECT * "
                    + "FROM estudante e INNER JOIN usuario u ON e.id_usuario = u.id_usuario "
                    + "INNER JOIN matricula m ON m.id_estudante = e.id_usuario "
                    + "WHERE id_curso = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, c.getId());
            rs = stmt.executeQuery();
            
            while(rs.next()) {
                Estudante e = new Estudante();
                e.setId(rs.getInt("id_usuario"));
                e.setNome(rs.getString("nome"));
                e.setEmail(rs.getString("email"));
                e.setCpf(rs.getString("cpf"));
                
                estudantes.add(e);
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar estudantes. Erro: " + ex.getMessage());
        } finally {
            Conexao.fecharConexao(con, stmt, rs);
        }
        
        return estudantes;
    }
}
